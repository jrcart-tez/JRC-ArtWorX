import { NFTStorage } from 'nft.storage';

export async function uploadToIPFS(file: File, name: string, description: string) {
  const client = new NFTStorage({ token: process.env.NFT_STORAGE_KEY! });

  const metadata = await client.store({
    name,
    description,
    image: file
  });

  return metadata.url;
}
