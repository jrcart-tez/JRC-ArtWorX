'use client';
import { useState } from 'react';

export default function Dashboard() {
  const [file, setFile] = useState<File | null>(null);
  const [price, setPrice] = useState('');
  const [supply, setSupply] = useState(1);
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('');

  async function deployArt() {
    if (!file) return;
    setStatus('Uploading + minting...');

    const form = new FormData();
    form.append('file', file);
    form.append('price', price);
    form.append('supply', supply.toString());
    form.append('title', title);

    const res = await fetch('/api/upload', { method: 'POST', body: form });
    const json = await res.json();
    setStatus(`Live! Frame: ${json.frame}`);
  }

  return (
    <main style={{ padding: 40 }}>
      <h1>Deploy New Artwork</h1>
      <input placeholder="Title" onChange={e => setTitle(e.target.value)} /><br/><br/>
      <input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} /><br/><br/>
      <input type="number" min={1} value={supply} onChange={e => setSupply(+e.target.value)} /> Editions<br/><br/>
      <input placeholder="Price in ETH" onChange={e => setPrice(e.target.value)} /><br/><br/>
      <button onClick={deployArt}>Deploy</button>
      <p>{status}</p>
    </main>
  );
}
