import { NextRequest } from 'next/server';
import { uploadToIPFS } from '@/lib/ipfs';
import { getContract } from '@/lib/contract';
import { parseEther } from 'ethers';

export async function POST(req: NextRequest) {
  const data = await req.formData();
  const file = data.get('file') as File;
  const price = data.get('price') as string;
  const supply = Number(data.get('supply'));
  const title = data.get('title') as string;

  const uri = await uploadToIPFS(file, title, 'JRC ArtWorX');
  const contract = getContract();

  await contract.createArt(parseEther(price), supply, uri);

  const frame = `${process.env.NEXT_PUBLIC_APP_URL}/api/frame/${Date.now()}`;

  return Response.json({ success: true, frame });
}
