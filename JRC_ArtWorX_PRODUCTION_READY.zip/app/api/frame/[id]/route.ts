import { getFrameHtmlResponse } from '@farcaster/frame-sdk';

export async function POST() {
  return new Response(getFrameHtmlResponse({
    image: 'https://placehold.co/600x600',
    buttons: [
      { label: 'Mint on Base', action: 'tx', target: '/api/mint' }
    ]
  }));
}
